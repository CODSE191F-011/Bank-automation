-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2020 at 09:58 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bankdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `AccNo` int(11) NOT NULL,
  `AccType` varchar(20) NOT NULL,
  `AccCreateDate` date NOT NULL,
  `AccHolderName` varchar(40) NOT NULL,
  `AccHolderNIC` varchar(15) NOT NULL,
  `AccHolderAge` varchar(5) NOT NULL,
  `AccHolderContactNo` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`AccNo`, `AccType`, `AccCreateDate`, `AccHolderName`, `AccHolderNIC`, `AccHolderAge`, `AccHolderContactNo`) VALUES
(100001, 'Fixed', '2020-03-09', 'jeashan anuja', '912345678V', '30', '0112624567'),
(100002, 'Saving', '2019-10-07', 'jeashan anuja', '912345678V', '21', '0772928615'),
(100003, 'Saving', '2019-12-01', 'Ashan perera', '990740895V', '30', '0772928615'),
(100004, 'Fixed', '2020-03-09', 'Ashan silva', '990740812V', '21', '0772938615'),
(100005, 'Saving', '2018-09-03', 'Nimali silva', '890740895V', '34', '0112124567'),
(100006, 'Fixed', '2018-06-12', 'Nimsha Disanayaka', '994040895V', '21', '0776193153'),
(100007, 'Saving', '2019-12-13', 'Nimsha Disanayaka', '994040895V', '21', '0776193153');

-- --------------------------------------------------------

--
-- Table structure for table `account_balance`
--

CREATE TABLE `account_balance` (
  `AccBalId` int(11) NOT NULL,
  `AccNo` varchar(12) NOT NULL,
  `AccType` varchar(20) NOT NULL,
  `AccBalance` int(11) NOT NULL,
  `AccInterest` int(11) NOT NULL,
  `IntrestDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_balance`
--

INSERT INTO `account_balance` (`AccBalId`, `AccNo`, `AccType`, `AccBalance`, `AccInterest`, `IntrestDate`) VALUES
(1, '100001', 'Fixed', 32700, 200, '2019-07-04'),
(2, '100002', 'Saving', 21600, 200, '2020-07-04'),
(3, '100003', 'Saving', 7828, 228, '2020-08-07'),
(4, '100004', 'Fixed', 1000, 5, '2020-07-08'),
(5, '100005', 'Saving', 30000, 300, '2020-07-04'),
(6, '100006', 'Fixed', 4500, 150, '2020-07-16'),
(7, '100007', 'Saving', 10000, 10, '2020-07-12');

-- --------------------------------------------------------

--
-- Table structure for table `branch_data`
--

CREATE TABLE `branch_data` (
  `ID` int(11) NOT NULL,
  `Branch` varchar(30) NOT NULL,
  `Availability` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch_data`
--

INSERT INTO `branch_data` (`ID`, `Branch`, `Availability`) VALUES
(1, 'Colombo07', 'Available'),
(2, 'Kiribathgoda', 'Unavailable'),
(3, 'Kadawatha', 'Unavailable'),
(4, 'Angoda', 'Unavailable'),
(5, 'Battaramulla', 'Available'),
(6, 'Nugegoda', 'Unavailable'),
(7, 'Kaduwela', 'Available'),
(8, 'Malabe', 'Unavailable'),
(9, 'Homagama', 'Unavailable');

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `DepID` int(11) NOT NULL,
  `AccNo` varchar(12) NOT NULL,
  `Deposit_Amount` int(30) NOT NULL,
  `Notes5000` int(30) DEFAULT NULL,
  `Notes1000` int(30) DEFAULT NULL,
  `Notes500` int(30) DEFAULT NULL,
  `Notes100` int(30) DEFAULT NULL,
  `DepositDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`DepID`, `AccNo`, `Deposit_Amount`, `Notes5000`, `Notes1000`, `Notes500`, `Notes100`, `DepositDate`) VALUES
(1, '100001', 5000, 1, 0, 0, 0, '2020-08-03'),
(2, '100001', 500, 0, 0, 1, 0, '2020-08-04'),
(3, '100001', 5000, 1, 0, 0, 0, '2020-08-04'),
(4, '100001', 600, 0, 0, 1, 1, '2020-08-04'),
(5, '100001', 6000, 1, 1, 0, 0, '2020-08-05'),
(6, '100002', 500, 0, 0, 1, 0, '2020-08-06'),
(7, '100003', 4000, 0, 4, 0, 0, '2020-08-06'),
(8, '100003', 600, 0, 0, 1, 1, '2020-08-06'),
(9, '100001', 100, 0, 0, 0, 1, '2020-08-06'),
(10, '100002', 600, 0, 0, 1, 1, '2020-08-06'),
(11, '100001', 500, 0, 0, 1, 0, '2020-08-07'),
(12, '100002', 500, 0, 0, 1, 0, '2020-08-08');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `LoanId` int(11) NOT NULL,
  `AccNo` varchar(12) NOT NULL,
  `AccType` varchar(20) NOT NULL,
  `LoanAmount` int(11) NOT NULL,
  `LoanDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`LoanId`, `AccNo`, `AccType`, `LoanAmount`, `LoanDate`) VALUES
(1, '100001', 'Fixed', 1200, '2020-08-05'),
(2, '100001', 'Fixed', 900, '2020-08-07'),
(3, '100003', 'Saving', 1000, '2020-08-08'),
(4, '100002', 'Saving', 20000, '2020-08-08');

-- --------------------------------------------------------

--
-- Table structure for table `loan_balance`
--

CREATE TABLE `loan_balance` (
  `LoanBalId` int(11) NOT NULL,
  `AccNo` varchar(12) NOT NULL,
  `AccType` varchar(20) NOT NULL,
  `LoanAmount` int(11) NOT NULL,
  `loanInterest` int(11) NOT NULL,
  `IntrestDate` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan_balance`
--

INSERT INTO `loan_balance` (`LoanBalId`, `AccNo`, `AccType`, `LoanAmount`, `loanInterest`, `IntrestDate`) VALUES
(1, '100003', 'Saving', 1020, 20, '2020-08-07'),
(2, '100005', 'Saving', 5000, 350, '2019-09-12'),
(3, '100006', 'Fixed', 2000, 20, '2019-07-14'),
(4, '100007', 'Saving', 10000, 1500, '2019-05-08'),
(5, '100004', 'Fixed', 2000, 100, '2019-07-13');

-- --------------------------------------------------------

--
-- Table structure for table `map_data`
--

CREATE TABLE `map_data` (
  `ID` int(11) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Colombo07` double NOT NULL,
  `Kiribathgoda` double NOT NULL,
  `Kadawatha` double NOT NULL,
  `Angoda` double NOT NULL,
  `Battaramulla` double NOT NULL,
  `Nugegoda` double NOT NULL,
  `Kaduwela` double NOT NULL,
  `Malabe` double NOT NULL,
  `Homagama` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `map_data`
--

INSERT INTO `map_data` (`ID`, `City`, `Colombo07`, `Kiribathgoda`, `Kadawatha`, `Angoda`, `Battaramulla`, `Nugegoda`, `Kaduwela`, `Malabe`, `Homagama`) VALUES
(1, 'Colombo07', 0, 13.7, 0, 10.1, 7.8, 8.1, 0, 0, 0),
(2, 'Kiribathgoda', 13.7, 0, 6, 6.1, 0, 0, 0, 0, 0),
(3, 'Kadawatha', 0, 6, 0, 0, 0, 0, 12.4, 0, 0),
(4, 'Angoda', 10.1, 6.1, 0, 0, 6.4, 0, 8.1, 9.6, 0),
(5, 'Battaramulla', 7.8, 0, 0, 6.4, 0, 7.2, 0, 7.2, 16.8),
(6, 'Nugegoda', 8.1, 0, 0, 0, 7.2, 0, 0, 0, 12.8),
(7, 'Kaduwela', 0, 0, 12.4, 8.1, 0, 0, 0, 3.2, 13.4),
(8, 'Malabe', 0, 0, 0, 9.6, 7.2, 0, 3.2, 0, 14),
(9, 'Homagama', 0, 0, 0, 0, 16.8, 12.8, 13.4, 14, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` int(11) NOT NULL,
  `First_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Mobile` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `First_Name`, `Last_Name`, `Mobile`, `Email`, `Address`, `Username`, `Password`) VALUES
(1, 'Sachith', 'Harshamal', 766887553, 'sachithharshamal9711@gmail.com', 'Gampaha', 'sachith', 'sa97');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`AccNo`);

--
-- Indexes for table `account_balance`
--
ALTER TABLE `account_balance`
  ADD PRIMARY KEY (`AccBalId`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`DepID`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`LoanId`);

--
-- Indexes for table `loan_balance`
--
ALTER TABLE `loan_balance`
  ADD PRIMARY KEY (`LoanBalId`);

--
-- Indexes for table `map_data`
--
ALTER TABLE `map_data`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `AccNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100008;
--
-- AUTO_INCREMENT for table `account_balance`
--
ALTER TABLE `account_balance`
  MODIFY `AccBalId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `DepID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `LoanId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `loan_balance`
--
ALTER TABLE `loan_balance`
  MODIFY `LoanBalId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
