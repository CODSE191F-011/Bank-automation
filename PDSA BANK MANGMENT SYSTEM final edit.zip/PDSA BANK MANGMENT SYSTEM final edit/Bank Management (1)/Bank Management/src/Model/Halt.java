package Model;

public class Halt {
	int id;
	String name;
	
	public Halt(int id, String name) {
		this.id = id;
		this.name = name;
	}
        
        public int id(){
            return id;
        }
        
        public String name(){
            return name;
        }
}
