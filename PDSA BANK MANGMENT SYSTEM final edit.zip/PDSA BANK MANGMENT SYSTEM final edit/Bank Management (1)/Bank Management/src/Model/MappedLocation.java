package Model;

public class MappedLocation {
	Halt startingPosition;
	Halt destination;
	int distance;
	String laneName;
	
	public MappedLocation(Halt startingPosition,Halt destination, int distance) {
		this.startingPosition = startingPosition;
		this.destination = destination;
		this.distance = distance;
		this.laneName = startingPosition+" -> "+destination;
	}
        
        public Halt startingPosition(){
            return startingPosition;
        }
        
        public Halt destination(){
            return destination;
        }
        
        public int distance(){
            return distance;
        }
        
        public String laneName(){
            return laneName;
        }
        
        public int startingPositionId(){
            return startingPosition.id;
        }
        
        public int destinationId(){
            return destination.id;
        }
}
