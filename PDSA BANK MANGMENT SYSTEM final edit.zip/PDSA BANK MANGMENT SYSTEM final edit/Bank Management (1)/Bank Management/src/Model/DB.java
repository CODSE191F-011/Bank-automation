/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import  java.sql.Connection;
import  java.sql.DriverManager;
/**
 *
 * @author Jeashan
 */
public class DB {
    public static  Connection createConnection()throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost/bankdb","root","");
                             return con;
    }
}
